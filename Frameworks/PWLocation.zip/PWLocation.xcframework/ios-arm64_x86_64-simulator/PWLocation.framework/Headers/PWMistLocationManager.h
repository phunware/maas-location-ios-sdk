//
//  PWMistLocationManager.h
//  PWLocation
//
//  Created by Troy Stump on 8/1/20.
//  Copyright © 2020 Phunware. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PWLocation/PWVBLocationManager.h>

NS_ASSUME_NONNULL_BEGIN

@interface PWMistLocationManager : PWVBLocationManager

@end

NS_ASSUME_NONNULL_END
